(function($) {

	$.extend(MediaElementPlayer.prototype, {
		buildplaylist : function(player, controls, layers, media) {
			if (!player.isVideo)
				return;

			// add speed controls
		}
	});
	
})(mejs.$);
